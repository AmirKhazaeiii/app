package com.example.flutter_secure_notes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
} 