# Secure Notes App

A secure, offline note-taking mobile application built with Flutter. This app stores all data locally on the device using SQLite database, ensuring complete privacy and offline functionality.

## 🔒 Security Features

- **No Internet Access**: App has no internet permissions
- **Local Database**: All data stored in device's SQLite database
- **No Cloud Sync**: Complete privacy - your notes stay on your device
- **No Analytics**: No tracking or data collection

## ✨ Features

- **📝 Create Notes**: Add new notes with title and content
- **✏️ Edit Notes**: Modify existing notes
- **🗑️ Delete Notes**: Remove notes with confirmation dialog
- **🔍 Search**: Search through notes by title or content
- **📅 Creation Date**: View when each note was created
- **🔄 Relative Time**: See how long ago notes were updated
- **🎨 Clean UI**: Minimal, light-colored interface
- **🔒 Offline Only**: No internet permissions required
- **💾 Local Storage**: All data stored locally using SQLite

## 🏗️ Architecture

### Frontend
- **Framework**: Flutter with Material Design
- **State Management**: Flutter's built-in StatefulWidget
- **Animations**: flutter_staggered_animations for smooth transitions

### Backend
- **Database**: SQLite with sqflite package
- **Storage**: Local device storage only
- **No External APIs**: Completely self-contained

### Database Schema
```sql
CREATE TABLE notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
```

## 📁 Project Structure

```
lib/
├── main.dart                 # App entry point and theme configuration
├── models/
│   └── note.dart            # Note data model with helper methods
├── database/
│   └── database_helper.dart  # SQLite database operations
├── screens/
│   ├── home_screen.dart      # Main screen with note list and search
│   └── note_edit_screen.dart # Create/edit note screen
└── widgets/
    └── note_card.dart        # Individual note display widget
```

## 🚀 Getting Started

### Prerequisites
- Flutter SDK (3.0.0 or higher)
- Android Studio (optional, for development)
- Android SDK

### Installation

1. **Clone or download this project**

2. **Install dependencies**:
   ```bash
   flutter pub get
   ```

3. **Run the app**:
   ```bash
   flutter run
   ```

4. **Build APK**:
   ```bash
   flutter build apk --release
   ```

### APK Location
The built APK will be located at:
```
build/app/outputs/flutter-apk/app-release.apk
```

## 📱 Usage

1. **Create a Note**: Tap the + button to create a new note
2. **Edit a Note**: Tap on any note to edit it
3. **Delete a Note**: Tap the delete icon on any note card
4. **Search Notes**: Use the search bar to find specific notes
5. **View Details**: See creation date and last modified time for each note

## 🎨 UI/UX Design

### Color Scheme
- **Background**: Light gray (#F8F9FA)
- **Cards**: White with subtle shadows
- **Primary**: Blue (#2196F3)
- **Text**: Dark gray (#212121)
- **Secondary Text**: Medium gray (#757575)

### Features
- **Responsive Design**: Works on different screen sizes
- **Smooth Animations**: Staggered list animations
- **Loading States**: Progress indicators during operations
- **Error Handling**: User-friendly error messages
- **Form Validation**: Input validation for all forms

## 🔧 Technical Details

### Dependencies
- `sqflite`: Local SQLite database
- `path`: Path manipulation utilities
- `intl`: Internationalization and date formatting
- `flutter_staggered_animations`: Smooth animations

### Key Classes

- **Note**: Data model with helper methods for date formatting
- **DatabaseHelper**: Singleton class managing all database operations
- **HomeScreen**: Main screen with search and list functionality
- **NoteEditScreen**: Form for creating and editing notes
- **NoteCard**: Reusable widget for displaying notes

### Error Handling
- Database operation failures
- Form validation errors
- User input validation
- Network state (though not used)

## 📋 Code Quality

### Comments and Documentation
The code includes extensive comments explaining:
- Database operations and SQL queries
- UI state management
- Form validation logic
- Error handling
- Animation configurations

### Best Practices
- Singleton pattern for database helper
- Proper state management
- Form validation
- Error boundaries
- Responsive design
- Accessibility considerations

## 🔒 Permissions

This app requires **NO** permissions:
- ❌ No internet access
- ❌ No camera access
- ❌ No location access
- ❌ No file system access (beyond app's own storage)
- ❌ No contacts access

## 🛠️ Development

### Running in Development Mode
```bash
flutter run
```

### Building for Release
```bash
flutter build apk --release
```

### Testing
```bash
flutter test
```

### Code Analysis
```bash
flutter analyze
```

## 📄 License

This project is created for educational purposes. Feel free to use and modify as needed.

## 🤝 Contributing

Feel free to submit issues and enhancement requests!

## 📞 Support

For issues or questions, please check the code comments for detailed explanations of each component. 