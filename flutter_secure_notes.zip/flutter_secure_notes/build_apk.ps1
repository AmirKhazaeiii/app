# Secure Notes App - Build Script
Write-Host "========================================" -ForegroundColor Green
Write-Host "Secure Notes App - Build Script" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

# Step 1: Install dependencies
Write-Host "Step 1: Installing dependencies..." -ForegroundColor Yellow
flutter pub get
if ($LASTEXITCODE -ne 0) {
    Write-Host "Failed to install dependencies!" -ForegroundColor Red
    Write-Host "Make sure Flutter is installed and in your PATH." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}
Write-Host "Dependencies installed successfully!" -ForegroundColor Green

# Step 2: Build APK
Write-Host ""
Write-Host "Step 2: Building APK..." -ForegroundColor Yellow
flutter build apk --release
if ($LASTEXITCODE -ne 0) {
    Write-Host "Failed to build APK!" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# Success message
Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "Build completed successfully!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Your APK is located at:" -ForegroundColor Yellow
Write-Host "build\app\outputs\flutter-apk\app-release.apk" -ForegroundColor Cyan
Write-Host ""
Write-Host "You can now install this APK on your Android device." -ForegroundColor White
Write-Host "Make sure to enable 'Install from unknown sources' in your device settings." -ForegroundColor White
Write-Host ""
Read-Host "Press Enter to exit" 